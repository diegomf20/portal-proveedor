<template>
    <v-app>
        <!-- <notifications group="foo" position="top center"/> -->
        <slot/>
    </v-app>
</template>

<script>
export default {

}
</script>
