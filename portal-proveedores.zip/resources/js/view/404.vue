<template>
    <h1>404 - No fastidiar</h1>
</template>
<script>
export default {
    
}
</script>